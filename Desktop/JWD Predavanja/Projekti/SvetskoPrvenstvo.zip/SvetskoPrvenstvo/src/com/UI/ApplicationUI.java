package com.UI;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.model.Drzava;
import com.model.SvetskoPrvenstvo;

import pomocnaKlasa.PomocnaKlasa;



public class ApplicationUI {

	public static ArrayList<Drzava> drzave = new ArrayList<>();
	public static ArrayList<SvetskoPrvenstvo> prvenstva = new ArrayList<>();

	public static void main(String[] args) {

		Connection conn;
		try {
			// ucitavanje MySQL drajvera
			Class.forName("com.mysql.jdbc.Driver");
			// otvaranje konekcije
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/prvenstva?useSSL=false", 
					"root", 
					"root");
		} catch (Exception ex) {
			System.out.println("Neuspela konekcija na bazu!");
			ex.printStackTrace();

			// kraj aplikacije
			return;
		}
		prikaz1(conn);
		prikaz2(conn);
		// prikaz menija
		String odluka = "";
		while (!odluka.equals("x")) {
			ispisiMenu();
			System.out.print("opcija:");
			odluka = PomocnaKlasa.ocitajTekst();
			switch (odluka) {				
			case "1":
				ispisDrzava();
				break;
			case "2":
				ispisPrve();
			case "3":
				unosIzmena(conn);
				break;
			case "4" :
				unosIzmena2(conn);
				break;
			case "5":
				prikaz5(conn);
				break;

			case "x":
				System.out.println("Izlaz");
				break;
			default:
				System.out.println("Nepostojeca komanda");
				break;
			}
		}

		// zatvaranje konekcije, jednom na kraju aplikacije
		try {
			conn.close();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	private static void prikazSvihDESC(Connection conn) {

		Statement stmt = null;
		ResultSet rset = null;
		try {
			String query = "SELECT godina,naziv,domacin,osvajac FROM prvenstvo "
					+ " ORDER  BY godina DESC";

			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			System.out.printf("%-5s %-20s %-8s %-8s", "godina", "naziv", "domacin", "osvajac"); System.out.println();
			System.out.println("===== ==================== ======== ========");
			// citanje rezultata upita
			while (rset.next()) {
				int index =1;
				int godina = rset.getInt(index++);
				String naziv = rset.getString(index++);
				int dom = rset.getInt(index++);
				int osv = rset.getInt(index++);
				//				int ptt = rset.getInt("ptt");
				//				String naziv = rset.getString("naziv");

				System.out.printf("%-5s %-20s %-8s %-8s", godina, naziv,dom,osv); 
				System.out.println();

			}

		} catch (SQLException ex) {
			System.out.println("Greska u SQL upitu!");
			ex.printStackTrace();
		} finally {
			
			try {rset.close();} catch (SQLException ex1) {ex1.printStackTrace();}
			try {stmt.close();} catch (SQLException ex1) {ex1.printStackTrace();}
		}

		// zatvaranje konekcije, jednom na kraju aplikacije
		try {
			conn.close();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	private static void unosIzmena(Connection conn) {
		String odluka = "";
		while (!odluka.equals("x")) {
			ispisiMenu2();
			System.out.print("opcija:");
			odluka = PomocnaKlasa.ocitajTekst();
			switch (odluka) {				
			case "1":
				unos(conn);
				prikaz1(conn);
				break;
			case "2":
				izmena(conn);
				prikaz1(conn);
				break;

			case "x":
				System.out.println("Izlaz");
				break;
			default:
				System.out.println("Nepostojeca komanda");
				break;

			}
		}
	}

	private static void unosIzmena2(Connection conn) {
		String odluka = "";
		while (!odluka.equals("x")) {
			ispisiMenu3();
			System.out.print("opcija:");
			odluka = PomocnaKlasa.ocitajTekst();
			switch (odluka) {				
			case "1":
				unosPrvenstva(conn);
				prikaz2(conn);
				break;
			case "2":
				izmenaPrvenstva(conn);
				prikaz2(conn);
				break;

			case "x":
				System.out.println("Izlaz");
				break;
			default:
				System.out.println("Nepostojeca komanda");
				break;

			}
		}
	}
	private static void prikaz5(Connection conn) {
		String odluka = "";
		while (!odluka.equals("x")) {
			ispisiMenu4();
			System.out.print("opcija:");
			odluka = PomocnaKlasa.ocitajTekst();
			switch (odluka) {				
			case "1":
				pretragaPoGodini(conn);
				break;
			case "2":
				prikazSvihDESC(conn);
				break;

			case "x":
				System.out.println("Izlaz");
				break;
			default:
				System.out.println("Nepostojeca komanda");
				break;

			}
		}
	}
	private static void pretragaPoGodini(Connection conn) {
		
		System.out.print("Uneti godinu:");
		int godina = PomocnaKlasa.ocitajCeoBroj();

		Statement stmt = null;
		ResultSet rset = null;
		try {
			String query = "SELECT * FROM prvenstvo ";

			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			System.out.printf("%-5s %-20s %-8s %-8s", "godina", "naziv", "domacin", "osvajac"); System.out.println();
			System.out.println("===== ==================== ======== ========");
			// citanje rezultata upita
			while (rset.next()) {
				int index =1;
				int godina2 = rset.getInt(index++);
				String naziv = rset.getString(index++);
				int dom = rset.getInt(index++);
				int osv = rset.getInt(index++);
				//				int ptt = rset.getInt("ptt");
				//				String naziv = rset.getString("naziv");
				if(godina == godina2) {
					System.out.printf("%-5s %-20s %-8s %-8s", godina, naziv,dom,osv); 
					System.out.println();
	
				}

			}

		} catch (SQLException ex) {
			System.out.println("Greska u SQL upitu!");
			ex.printStackTrace();
		} finally {
			
			try {rset.close();} catch (SQLException ex1) {ex1.printStackTrace();}
			try {stmt.close();} catch (SQLException ex1) {ex1.printStackTrace();}
		}

		// zatvaranje konekcije, jednom na kraju aplikacije
		try {
			conn.close();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		
	}

	private static void izmenaPrvenstva(Connection conn) {

		System.out.print("Uneti godinu:");
		int godina = PomocnaKlasa.ocitajCeoBroj();

		System.out.print("Uneti novi naziv:");
		String naziv = PomocnaKlasa.ocitajTekst();


		System.out.print("Uneti novi id domacina: ");
		int dom = PomocnaKlasa.ocitajCeoBroj();

		System.out.print("Uneti novi id osvajaca: ");
		int osv = PomocnaKlasa.ocitajCeoBroj();


		// sadrzaj objekta ubacimo u bazu podataka
		PreparedStatement pstmt = null;
		try {
			String query = "UPDATE prvenstva.prvenstvo SET naziv = ?, domacin =?, osvajac =?  WHERE godina = ? ";

			pstmt = conn.prepareStatement(query);
			int index =1;
			pstmt.setString(index++, naziv);
			pstmt.setInt(index++, dom);
			pstmt.setInt(index++, osv);
			pstmt.setInt(index++, godina);
			if (pstmt.executeUpdate() != 1)
				System.out.println("Greska u SQL upitu!");
		} catch (SQLException ex) {
			System.out.println("Greska u SQL upitu!");
			ex.printStackTrace();
		} finally {
			try {pstmt.close();} catch (SQLException ex1) {ex1.printStackTrace();}
		}

		System.out.println("Drzava je uspesno izmenjena");

	}

	private static void unosPrvenstva(Connection conn) {


		System.out.print("Uneti godinu:");
		int godina = PomocnaKlasa.ocitajCeoBroj();

		System.out.print("Uneti naziv:");
		String naziv = PomocnaKlasa.ocitajTekst();


		System.out.print("Uneti id domacina: ");
		int dom = PomocnaKlasa.ocitajCeoBroj();

		System.out.print("Uneti id osvajaca: ");
		int osv = PomocnaKlasa.ocitajCeoBroj();

		// kreiramo objekat student u memoriji



		// sadrzaj objekta ubacimo u bazu podataka
		PreparedStatement pstmt = null;
		try {
			String query = "INSERT INTO prvenstva.prvenstvo (godina,naziv,domacin,osvajac) VALUES (?,?,?,?)";

			pstmt = conn.prepareStatement(query);
			int index = 1;
			pstmt.setInt(index++, godina);
			pstmt.setString(index++, naziv );
			pstmt.setInt(index++, dom);
			pstmt.setInt(index++, osv);

			if (pstmt.executeUpdate() != 1)
				System.out.println("Greska u SQL upitu!");
		} catch (SQLException ex) {
			System.out.println("Greska u SQL upitu!");
			ex.printStackTrace();
		} finally {
			try {pstmt.close();} catch (SQLException ex1) {ex1.printStackTrace();}
		}

		System.out.println("Prvestvo je uspesno dodato");

	}

	private static void izmena(Connection conn) {


		System.out.print("Uneti ID drzave:");
		int id = PomocnaKlasa.ocitajCeoBroj();


		System.out.print("Uneti naziv:");
		String naziv = PomocnaKlasa.ocitajTekst();


		// sadrzaj objekta ubacimo u bazu podataka
		PreparedStatement pstmt = null;
		try {
			String query = "UPDATE prvenstva.drzava SET naziv = ? WHERE id = ? ";

			pstmt = conn.prepareStatement(query);
			int index =1;
			pstmt.setString(index++, naziv);
			pstmt.setInt(index++, id);

			if (pstmt.executeUpdate() != 1)
				System.out.println("Greska u SQL upitu!");
		} catch (SQLException ex) {
			System.out.println("Greska u SQL upitu!");
			ex.printStackTrace();
		} finally {
			try {pstmt.close();} catch (SQLException ex1) {ex1.printStackTrace();}
		}

		System.out.println("Drzava je uspesno izmenjena");

	}

	private static void unos(Connection conn) {
		System.out.print("Uneti naziv:");
		String naziv = PomocnaKlasa.ocitajTekst();


		// kreiramo objekat student u memoriji
		Drzava dr = new Drzava(0,naziv);

		// sadrzaj objekta ubacimo u bazu podataka
		PreparedStatement pstmt = null;
		try {
			String query = "INSERT INTO drzava (naziv) VALUES (?)";

			pstmt = conn.prepareStatement(query);
			int index = 1;
			pstmt.setString(index++, dr.getNaziv());

			if (pstmt.executeUpdate() != 1)
				System.out.println("Greska u SQL upitu!");
		} catch (SQLException ex) {
			System.out.println("Greska u SQL upitu!");
			ex.printStackTrace();
		} finally {
			try {pstmt.close();} catch (SQLException ex1) {ex1.printStackTrace();}
		}

		System.out.println("Drzava je uspesno dodata");
	}



	private static void prikaz2(Connection conn) {
		//		List<SvetskoPrvenstvo> prvenstvo = new ArrayList<>(); // imamo vec gore static listu

		prvenstva.clear();
		Statement stmt = null;
		ResultSet rset = null;
		try {
			String query = "SELECT * FROM prvenstvo";

			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);

			// citanje rezultata upita i punjenje liste
			while (rset.next()) {
				int index = 1;
				int godina = rset.getInt(index++);
				String naziv = rset.getString(index++);
				int domacin = rset.getInt(index++);
				int osvajac = rset.getInt(index++);

				Drzava dom = null;
				Drzava osv = null;
				for (int i = 0; i < drzave.size(); i++) {
					if (domacin==drzave.get(i).getId()) {
						dom = drzave.get(i);
					}
				}
				for (int i = 0; i < drzave.size(); i++) {
					if (osvajac==drzave.get(i).getId()) {
						osv = drzave.get(i);
					}

				}
				// kreiramo objekat u memoriji na osnovu preuzetog sloga iz baze
				//				Student student = new Student(id, indeks, ime, prezime);
				SvetskoPrvenstvo prvenstvo = new SvetskoPrvenstvo(godina, naziv, dom, osv);
				prvenstva.add(prvenstvo);
			}

		} catch (SQLException ex) {
			System.out.println("Greska u SQL upitu!");
			ex.printStackTrace();
		}  finally {
			try {rset.close();} catch (SQLException ex1) {ex1.printStackTrace();}
			try {stmt.close();} catch (SQLException ex1) {ex1.printStackTrace();}
		}

		// sada imamo napunjenu listu studenata u memoriji 
		// prolazimo kroz listu i ispisujemo podatke o svakom studentu

	}

	private static void ispisPrve() {
		System.out.println();
		System.out.printf("%-5s %-20s %-20s %-20s", "godina", "Naziv", "Domacin", "Osvajac"); 
		System.out.println();
		System.out.println("===== ==================== ==================== ====================");
		for (SvetskoPrvenstvo temp: prvenstva) {
			System.out.printf("%-5s %-20s %-20s %-20s", temp.getGodina(), temp.getNaziv(), temp.getDomacin(), temp.getOsvajac());
			System.out.println();
		}

	}
	private static void prikaz1(Connection conn) {
		//	List<Drzava> drzave = new ArrayList<>(); // lista studenata u memoriji
		drzave.clear();
		Statement stmt = null;
		ResultSet rset = null;
		try {
			String query = "SELECT * FROM drzava";

			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);

			// citanje rezultata upita i punjenje liste
			while (rset.next()) {
				int index = 1;
				int id = rset.getInt(index++);
				String naziv = rset.getString(index++);

				// kreiramo objekat u memoriji na osnovu preuzetog sloga iz baze
				//				Student student = new Student(id, indeks, ime, prezime);
				Drzava drzava = new Drzava(id,naziv);
				drzave.add(drzava);
			}
		} catch (SQLException ex) {
			System.out.println("Greska u SQL upitu!");
			ex.printStackTrace();
		}  finally {
			try {rset.close();} catch (SQLException ex1) {ex1.printStackTrace();}
			try {stmt.close();} catch (SQLException ex1) {ex1.printStackTrace();}
		}

		// sada imamo napunjenu listu studenata u memoriji 
		// prolazimo kroz listu i ispisujemo podatke o svakom studentu

	}
	private static void ispisDrzava() {

		System.out.println();
		System.out.printf("%-5s %-20s ", "id", "naziv"); 
		System.out.println();
		System.out.println("===== ====================");
		for (Drzava temp: drzave) {
			System.out.printf("%-5s %-20s", temp.getId(), temp.getNaziv());
			System.out.println();
		}
	}

	private static void ispisiMenu() {
		System.out.println();
		System.out.println("Meni:");
		System.out.println("\t1 - Prikazi sve drzave");
		System.out.println("\t2 - Prikazi sva svetska prvenstva");
		System.out.println("\t3 - Unos i izmenu drzava");
		System.out.println("\t4 - Unos i izmenu svetskih prvenstava");
		System.out.println("\t5 - Pretraga i prikaz svetskih prvenstava po godini odrzavanja");


		System.out.println("\tx - IZLAZ IZ PROGRAMA");
	}
	private static void ispisiMenu2() {
		System.out.println();
		System.out.println("Meni:");
		System.out.println("\t1 - Unos Drzave");
		System.out.println("\t2 - Izmena Drzave");

		System.out.println("\tx - IZLAZ IZ PROGRAMA");
	}
	private static void ispisiMenu3() {
		System.out.println();
		System.out.println("Meni:");
		System.out.println("\t1 - Unos prvenstva");
		System.out.println("\t2 - Izmena prvenstva");

		System.out.println("\tx - IZLAZ IZ PROGRAMA");
	}
	private static void ispisiMenu4() {
		System.out.println();
		System.out.println("Meni:");
		System.out.println("\t1 - Pretraga po godini");
		System.out.println("\t2 - Ispish svi po godini u opadajucem");

		System.out.println("\tx - IZLAZ IZ PROGRAMA");
	}
}
