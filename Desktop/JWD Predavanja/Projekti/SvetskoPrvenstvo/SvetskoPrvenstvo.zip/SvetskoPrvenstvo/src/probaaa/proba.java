package probaaa;

import javax.swing.*;
import javax.*;
import java.awt.*;
import java.awt.event.*;


public class proba {
	public static void main(String []args) {
		JFrame frame = new JFrame("Svetska Prvenstva");
		frame.setVisible(true);
		frame.setSize(500, 650);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JLabel label = new JLabel("Glavni Meni");
		JPanel panel = new JPanel();
		frame.add(panel);
		panel.add(label);
		


		JButton button1 = new JButton("Prikaz svih Drzava");
		JButton button2 = new JButton("Prikaz svih prvenstava");
		JButton button3 = new JButton("Rad sa Drzavama");
		panel.add(button1);
		panel.add(button2);
		panel.add(button3);
		button1.addActionListener(new Action());
	}

	static class Action implements ActionListener{

		public void actionPerformed(ActionEvent e) {
			JFrame frame2 = new JFrame("Prikaz svih drzava");
			frame2.setVisible(true);
			frame2.setSize(300,450);
			JLabel label = new JLabel("Drzave\n");
			JPanel panel = new JPanel();
			frame2.add(panel);
			panel.add(label);
		}
	}
}